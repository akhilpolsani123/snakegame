import "@/app/globals.css"
import Game from "../components/Game"

export default function Home() {
  return (
    <main>
      <Game />
    </main>
  )
}

